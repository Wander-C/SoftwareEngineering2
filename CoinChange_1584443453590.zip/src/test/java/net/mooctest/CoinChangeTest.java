package net.mooctest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;

public class CoinChangeTest {

	@Test(timeout = 4000)
	public void test0() throws Throwable {
		CoinChange nCoin = new CoinChange();
	}

}
